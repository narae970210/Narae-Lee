/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=30x20 bird bird.png 
 * Time-stamp: Sunday 04/07/2019, 23:49:42
 * 
 * Image Information
 * -----------------
 * bird.png 30@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BIRD_H
#define BIRD_H

extern const unsigned short bird[600];
#define BIRD_SIZE 1200
#define BIRD_LENGTH 600
#define BIRD_WIDTH 30
#define BIRD_HEIGHT 20

#endif

