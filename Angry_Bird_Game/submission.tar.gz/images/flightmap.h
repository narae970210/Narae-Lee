/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 flightmap flightmap.png 
 * Time-stamp: Sunday 04/07/2019, 22:15:31
 * 
 * Image Information
 * -----------------
 * flightmap.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLIGHTMAP_H
#define FLIGHTMAP_H

extern const unsigned short flightmap[38400];
#define FLIGHTMAP_SIZE 76800
#define FLIGHTMAP_LENGTH 38400
#define FLIGHTMAP_WIDTH 240
#define FLIGHTMAP_HEIGHT 160

#endif

