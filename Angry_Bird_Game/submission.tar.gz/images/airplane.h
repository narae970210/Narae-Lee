/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=60x40 airplane airplane.png 
 * Time-stamp: Monday 04/08/2019, 21:38:37
 * 
 * Image Information
 * -----------------
 * airplane.png 60@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef AIRPLANE_H
#define AIRPLANE_H

extern const unsigned short airplane[2400];
#define AIRPLANE_SIZE 4800
#define AIRPLANE_LENGTH 2400
#define AIRPLANE_WIDTH 60
#define AIRPLANE_HEIGHT 40

#endif

