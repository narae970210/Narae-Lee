/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 clouds clouds.png 
 * Time-stamp: Sunday 04/07/2019, 20:39:13
 * 
 * Image Information
 * -----------------
 * clouds.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CLOUDS_H
#define CLOUDS_H

extern const unsigned short clouds[38400];
#define CLOUDS_SIZE 76800
#define CLOUDS_LENGTH 38400
#define CLOUDS_WIDTH 240
#define CLOUDS_HEIGHT 160

#endif

