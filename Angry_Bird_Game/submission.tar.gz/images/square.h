/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=8x8 square square.jpg 
 * Time-stamp: Thursday 04/11/2019, 22:30:30
 * 
 * Image Information
 * -----------------
 * square.jpg 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SQUARE_H
#define SQUARE_H

extern const unsigned short square[64];
#define SQUARE_SIZE 128
#define SQUARE_LENGTH 64
#define SQUARE_WIDTH 8
#define SQUARE_HEIGHT 8

#endif

